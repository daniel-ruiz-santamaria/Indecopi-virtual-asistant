﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IndecopiVirtualAsistant.Models
{
    public class KeyVaultModel
    {
        public string ConnectionStringKeyVault { get; set; }

        public string TokenKeyVault { get; set; }
    }
}
